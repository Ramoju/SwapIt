const defs = {
    baseUrl: "http://10.0.2.2:3000/api",
    defaultImgUri: "https://ui-avatars.com/api/?background=d268ee&color=fff&rounded=true&name=Sport+spot"
};

export default defs;